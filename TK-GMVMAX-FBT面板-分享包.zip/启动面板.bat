@echo off
chcp 65001 >nul
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Python，请先安装：https://www.python.org/downloads/
  echo 安装时请勾选 "Add Python to PATH"。
  pause
  exit /b 1
)
echo 正在安装依赖（首次运行需要一点时间）...
python -m pip install -r requirements.txt
echo 启动面板中，浏览器将自动打开 http://127.0.0.1:8501
python dashboard_server.py
pause
